# fhir.314e#1.0.0: 314e FHIR Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile-definitions.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile-mappings.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile-testing.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile.ai.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile.profile.history.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile.profile.json.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile.profile.ttl.md)
* [](StructureDefinition-attachment-inlineDataSavedAsFile.profile.xml.md)

## Resources

### CodeSystems

* [Attachment Tag CodeSystem](CodeSystem-attachment-tag.md)

### ValueSets

* [Attachment Tag ValueSet](ValueSet-attachment-tag.md)

### Complex-type Profiles

* [314e Annotation](StructureDefinition-annotation-314e.md)
* [314e Attachment](StructureDefinition-attachment-314e.md)
* [314e Quantity](StructureDefinition-quantity-314e.md)
* [314e Reference](StructureDefinition-reference-314e.md)

### Extensions

* [Annotation Attachment](StructureDefinition-annotation-attachment.md)
* [Attachment Helper File](StructureDefinition-attachment-helperFile.md)
* [Attachment Tag](StructureDefinition-attachment-tag.md)
* [Quantity Quantity String](StructureDefinition-quantity-quantityString.md)
* [Quantity Value String](StructureDefinition-quantity-valueString.md)
* [Reference Context](StructureDefinition-reference-context.md)

### ImplementationGuides

* [314e FHIR Implementation Guide](ImplementationGuide-fhir.314e.md)
