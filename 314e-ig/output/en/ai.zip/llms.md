# fhir.314e#1.0.0: 314e FHIR Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Complex Datatypes](complex-datatypes.md)
* [Extensions](extensions.md)
* [Resource Profiles](resource-profiles.md)
* [Simple Datatypes](simple-datatypes.md)
* [](StructureDefinition-value-attachment-314e-definitions.md)
* [](StructureDefinition-value-attachment-314e-mappings.md)
* [](StructureDefinition-value-attachment-314e-testing.md)
* [](StructureDefinition-value-attachment-314e.ai.md)
* [](StructureDefinition-value-attachment-314e.md)
* [](StructureDefinition-value-attachment-314e.profile.history.md)
* [](StructureDefinition-value-attachment-314e.profile.json.md)
* [](StructureDefinition-value-attachment-314e.profile.ttl.md)
* [](StructureDefinition-value-attachment-314e.profile.xml.md)
* [Terminology](terminology.md)

## Resources

### CodeSystems

* [Attachment Tag CodeSystem](CodeSystem-attachment-tag-cs.md)
* [Observation Tag CodeSystem](CodeSystem-observation-tag.md)
* [314e Procedure Category CodeSystem](CodeSystem-procedure-category-314e.md)
* [314e Time Precision Units](CodeSystem-time-precision-units-cs.md)

### ValueSets

* [Antimicrobial Susceptibility Testing](ValueSet-antimicrobial-susceptibility-testing-vs.md)
* [Attachment Tag ValueSet](ValueSet-attachment-tag.md)
* [314e Lab Subcategories](ValueSet-lab-category-subcategory-314e.md)
* [Microorganism by Method](ValueSet-microorganism-by-method-vs.md)
* [Observation Tag ValueSet](ValueSet-observation-tag-vs.md)
* [314e Broad Procedure Categories](ValueSet-procedure-category-broad-314e.md)
* [314e Procedure Subcategories](ValueSet-procedure-category-subcategory-314e.md)
* [314e Time Exactness Units ValueSet](ValueSet-time-accuracy-units-vs.md)
* [314e Time Precision Units ValueSet](ValueSet-time-precision-units-vs.md)

### Complex-type Profiles

* [314e Address](StructureDefinition-address-314e.md)
* [314e Age](StructureDefinition-age-314e.md)
* [314e Annotation](StructureDefinition-annotation-314e.md)
* [314e Attachment](StructureDefinition-attachment-314e.md)
* [314e CodeableConcept](StructureDefinition-codeableconcept-314e.md)
* [314e Coding](StructureDefinition-coding-314e.md)
* [314e ContactPoint](StructureDefinition-contactpoint-314e.md)
* [314e Duration](StructureDefinition-duration-314e.md)
* [314e HumanName](StructureDefinition-humanname-314e.md)
* [314e Identifier](StructureDefinition-identifier-314e.md)
* [314e Period](StructureDefinition-period-314e.md)
* [314e Quantity](StructureDefinition-quantity-314e.md)
* [314e Range](StructureDefinition-range-314e.md)
* [314e Ratio](StructureDefinition-ratio-314e.md)
* [314e Reference](StructureDefinition-reference-314e.md)
* [314e SampledData](StructureDefinition-sampleddata-314e.md)
* [314e SimpleQuantity](StructureDefinition-simplequantity-314e.md)
* [314e Timing](StructureDefinition-timing-314e.md)

### Primitive-type Profiles

* [314e dateTime](StructureDefinition-datetime-314e.md)
* [314e decimal](StructureDefinition-decimal-314e.md)
* [314e instant](StructureDefinition-instant-314e.md)
* [314e time](StructureDefinition-time-314e.md)

### Resource Profiles

* [314e AllergyIntolerance](StructureDefinition-allergyintolerance-314e.md)
* [314e CarePlan](StructureDefinition-careplan-314e.md)
* [314e Condition](StructureDefinition-condition-314e.md)
* [314e Condition Encounter Diagnosis](StructureDefinition-condition-diagnosis-314e.md)
* [314e Condition Problems Health Concerns](StructureDefinition-condition-problem-healthconcern-314e.md)
* [314e DiagnosticReport](StructureDefinition-diagnosticreport-314e.md)
* [314e DiagnosticReport Laboratory Results](StructureDefinition-diagnosticreport-lab-314e.md)
* [314e DiagnosticReport Note and Report](StructureDefinition-diagnosticreport-notereport-314e.md)
* [314e DocumentReference](StructureDefinition-documentreference-314e.md)
* [314e Encounter](StructureDefinition-encounter-314e.md)
* [314e Episode Of Care](StructureDefinition-episodeofcare-314e.md)
* [314e Immunization](StructureDefinition-immunization-314e.md)
* [314e Observation](StructureDefinition-observation-314e.md)
* [314e Antimicrobial Susceptibility Observation](StructureDefinition-observation-antimicrobial-susceptibility-314e.md)
* [314e General Laboratory Observation](StructureDefinition-observation-lab-general-314e.md)
* [314e Microbiology Observation](StructureDefinition-observation-microbiology-314e.md)
* [314e Microorganism Observation](StructureDefinition-observation-microorganism-314e.md)
* [314e Patient](StructureDefinition-patient-314e.md)
* [314e Practitioner](StructureDefinition-practitioner-314e.md)
* [314e RelatedPerson](StructureDefinition-relatedperson-314e.md)
* [314e ServiceRequest](StructureDefinition-servicerequest-314e.md)
* [314e Specimen](StructureDefinition-specimen-314e.md)

### Extensions

* [Annotation Attachment](StructureDefinition-annotation-attachment.md)
* [Attachment Helper File](StructureDefinition-attachment-helperFile.md)
* [Attachment Tag](StructureDefinition-attachment-tag.md)
* [Care Plan Activity Target Date Time](StructureDefinition-carePlan-activity-targetDateTime.md)
* [Care Plan Target Date Time](StructureDefinition-carePlan-targetDateTime.md)
* [Cosigner](StructureDefinition-cosigner.md)
* [Date/Time Accuracy](StructureDefinition-datetime-accuracy.md)
* [Date/Time Precision](StructureDefinition-datetime-precision.md)
* [Document Reference Author Dictation Date Time](StructureDefinition-documentReference-author-dictationDateTime.md)
* [Document Reference Context Cosigner](StructureDefinition-documentReference-context-cosigner.md)
* [Document Reference Context Dictation Date Time](StructureDefinition-documentReference-context-dictationDateTime.md)
* [Document Reference Context Report Date Time](StructureDefinition-documentReference-context-reportDateTime.md)
* [Element Additional Info](StructureDefinition-element-additionalInfo.md)
* [Observation Value Attachment](StructureDefinition-observation-value-attachment.md)
* [Patient Affiliation](StructureDefinition-patient-affiliation.md)
* [Patient Employment Status](StructureDefinition-patient-employmentStatus.md)
* [Patient Mother's Name](StructureDefinition-patient-mothersName.md)
* [Patient Pharmacies](StructureDefinition-patient-pharmacies.md)
* [Patient Preferred Gender Pronoun](StructureDefinition-patient-preferredGenderPronoun.md)
* [Quantity Quantity String](StructureDefinition-quantity-quantityString.md)
* [Quantity Value String](StructureDefinition-quantity-valueString.md)
* [Reference Context](StructureDefinition-reference-context.md)
* [Related Person Encounter](StructureDefinition-relatedPerson-encounter.md)
* [Resource Additional Info](StructureDefinition-resource-additionalInfo.md)
* [Resource Episode](StructureDefinition-resource-episode.md)
* [Resource Last Edited User](StructureDefinition-resource-lastEditedUser.md)
* [Time Accuracy](StructureDefinition-time-accuracy.md)
* [Time Precision](StructureDefinition-time-precision.md)

### ImplementationGuides

* [314e FHIR Implementation Guide](ImplementationGuide-fhir.314e.md)
