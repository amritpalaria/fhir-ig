# fhir.314e#1.0.0: 314e FHIR Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)

## Resources

### CodeSystems

* [Attachment Tag CodeSystem](CodeSystem-attachment-tag.md)
* [Observation Tag CodeSystem](CodeSystem-observation-tag.md)
* [314e Procedure Category CodeSystem](CodeSystem-procedure-category-314e.md)

### ValueSets

* [Attachment Tag ValueSet](ValueSet-attachment-tag.md)
* [Observation Tag ValueSet](ValueSet-observation-tag.md)
* [314e Broad Procedure Categories](ValueSet-procedure-category-broad-314e.md)
* [314e Procedure Subcategories](ValueSet-procedure-category-subcategory-314e.md)

### Complex-type Profiles

* [314e Annotation](StructureDefinition-annotation-314e.md)
* [314e Attachment](StructureDefinition-attachment-314e.md)
* [314e CodeableConcept](StructureDefinition-codeableconcept-314e.md)
* [314e Coding](StructureDefinition-coding-314e.md)
* [314e Identifier](StructureDefinition-identifier-314e.md)
* [314e Quantity](StructureDefinition-quantity-314e.md)
* [314e Range](StructureDefinition-range-314e.md)
* [314e Ratio](StructureDefinition-ratio-314e.md)
* [314e Reference](StructureDefinition-reference-314e.md)
* [314e SimpleQuantity](StructureDefinition-simplequantity-314e.md)

### Resource Profiles

* [314e ServiceRequest](StructureDefinition-servicerequest-314e.md)

### Extensions

* [Annotation Attachment](StructureDefinition-annotation-attachment.md)
* [Attachment Helper File](StructureDefinition-attachment-helperFile.md)
* [Attachment Tag](StructureDefinition-attachment-tag.md)
* [Quantity Quantity String](StructureDefinition-quantity-quantityString.md)
* [Quantity Value String](StructureDefinition-quantity-valueString.md)
* [Reference Context](StructureDefinition-reference-context.md)

### ImplementationGuides

* [314e FHIR Implementation Guide](ImplementationGuide-fhir.314e.md)
