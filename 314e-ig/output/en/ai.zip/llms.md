# fhir.314e#1.0.0: 314e FHIR Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Complex Datatypes](complex-datatypes.md)
* [Extensions](extensions.md)
* [Resource Profiles](resource-profiles.md)
* [Simple Datatypes](simple-datatypes.md)
* [Terminology](terminology.md)

## Resources

### CodeSystems

* [Attachment Tag CodeSystem](CodeSystem-attachment-tag-cs.md)
* [Observation Tag CodeSystem](CodeSystem-observation-tag.md)
* [314e Procedure Category CodeSystem](CodeSystem-procedure-category-314e.md)
* [314e Time Precision Units](CodeSystem-time-precision-units-cs.md)

### ValueSets

* [Antimicrobial Susceptibility Testing](ValueSet-antimicrobial-susceptibility-testing-vs.md)
* [Attachment Tag ValueSet](ValueSet-attachment-tag.md)
* [314e Lab Subcategories](ValueSet-lab-category-subcategory-314e.md)
* [Microorganism by Method](ValueSet-microorganism-by-method-vs.md)
* [Observation Tag ValueSet](ValueSet-observation-tag-vs.md)
* [314e Broad Procedure Categories](ValueSet-procedure-category-broad-314e.md)
* [314e Procedure Subcategories](ValueSet-procedure-category-subcategory-314e.md)
* [314e Time Exactness Units ValueSet](ValueSet-time-accuracy-units-vs.md)
* [314e Time Precision Units ValueSet](ValueSet-time-precision-units-vs.md)

### Complex-type Profiles

* [314e Annotation](StructureDefinition-annotation-314e.md)
* [314e Attachment](StructureDefinition-attachment-314e.md)
* [314e CodeableConcept](StructureDefinition-codeableconcept-314e.md)
* [314e Coding](StructureDefinition-coding-314e.md)
* [314e Duration](StructureDefinition-duration-314e.md)
* [314e Identifier](StructureDefinition-identifier-314e.md)
* [314e Period](StructureDefinition-period-314e.md)
* [314e Quantity](StructureDefinition-quantity-314e.md)
* [314e Range](StructureDefinition-range-314e.md)
* [314e Ratio](StructureDefinition-ratio-314e.md)
* [314e Reference](StructureDefinition-reference-314e.md)
* [314e SampledData](StructureDefinition-sampleddata-314e.md)
* [314e SimpleQuantity](StructureDefinition-simplequantity-314e.md)
* [314e Timing](StructureDefinition-timing-314e.md)

### Primitive-type Profiles

* [314e dateTime](StructureDefinition-datetime-314e.md)
* [314e decimal](StructureDefinition-decimal-314e.md)
* [314e instant](StructureDefinition-instant-314e.md)
* [314e time](StructureDefinition-time-314e.md)

### Resource Profiles

* [314e Antimicrobial Susceptibility Observation](StructureDefinition-observation-antimicrobial-susceptibility-314e.md)
* [314e General Laboratory Observation](StructureDefinition-observation-lab-general-314e.md)
* [314e Microbiology Observation](StructureDefinition-observation-microbiology-314e.md)
* [314e Microorganism Observation](StructureDefinition-observation-microorganism-314e.md)
* [314e ServiceRequest](StructureDefinition-servicerequest-314e.md)

### Extensions

* [Annotation Attachment](StructureDefinition-annotation-attachment.md)
* [Attachment Helper File](StructureDefinition-attachment-helperFile.md)
* [Attachment Tag](StructureDefinition-attachment-tag.md)
* [314e Date/Time Accuracy](StructureDefinition-datetime-accuracy-314e.md)
* [314e Date/Time Precision](StructureDefinition-datetime-precision-314e.md)
* [Quantity Quantity String](StructureDefinition-quantity-quantityString.md)
* [Quantity Value String](StructureDefinition-quantity-valueString.md)
* [Reference Context](StructureDefinition-reference-context.md)
* [314e Time Accuracy](StructureDefinition-time-accuracy-314e.md)
* [314e Time Precision](StructureDefinition-time-precision-314e.md)
* [314e Observation Value Attachment](StructureDefinition-value-attachment-314e.md)

### ImplementationGuides

* [314e FHIR Implementation Guide](ImplementationGuide-fhir.314e.md)
