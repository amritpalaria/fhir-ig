<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile SimpleQuantity
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Quantity</sch:title>
    <sch:rule context="f:Quantity">
      <sch:assert test="count(f:extension[@url = 'http://314e.com/fhir/StructureDefinition/quantity-quantityString']) &lt;= 1">extension with URL = 'http://314e.com/fhir/StructureDefinition/quantity-quantityString': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:Quantity/f:value</sch:title>
    <sch:rule context="f:Quantity/f:value">
      <sch:assert test="count(f:id) &lt;= 1">id: maximum cardinality of 'id' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://hl7.org/fhir/StructureDefinition/quantity-precision']) &lt;= 1">extension with URL = 'http://hl7.org/fhir/StructureDefinition/quantity-precision': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://314e.com/fhir/StructureDefinition/quantity-valueString']) &lt;= 1">extension with URL = 'http://314e.com/fhir/StructureDefinition/quantity-valueString': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:value) &lt;= 1">value: maximum cardinality of 'value' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
